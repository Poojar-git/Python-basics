print("THis is the virtual environment")
print("It has its own python compiler, installed packages and independent dependencies")
